Assignment: 3 
Class: Comp 3004
Student Name: Hamda Khalif 
Student Number: 101237070
Notes: Please note that QT was very slow for me on TurboVNC. Please contact me if any additional questions, comments, or concerns. Thank You

Project: Elevator Simulation Project
## This project implements a Qt/C++ elevator simulation that supports: ## 
- Multiple floors and elevators
- Passenger events (requests to move between floors)
- Safety events (Fire, DoorObstacle, etc.)
- A simple GUI to visualize elevator states and floors
- Simulation time stepping, starting at 0 and incrementing each second

## This repository contains a Qt/C++ implementation of an elevator simulation, including passenger events, safety events, and a GUI to visualize elevator states. Below is a breakdown of each source and header file in the project. ## 

## File Structure: ## 
ElevatorSimulation
├── main.cpp
├── MainWindow.h
├── MainWindow.cpp
├── SimulationController.h
├── SimulationController.cpp
├── ElevatorWidget.h
├── ElevatorWidget.cpp
├── FloorWidget.h
├── FloorWidget.cpp
└── ( and additional .pro or CMake files)


1. main.cpp
## Purpose: ## 

## The entry point of the Qt application.
Creates a QApplication instance and a MainWindow object, then calls app.exec() to start the Qt event loop.

## Key Logic: ## 
- Instantiates MainWindow w;
- Calls w.show(); to display the main window.
- Returns the exit code after app.exec() completes.

## Typical Contents: ##

#include <QApplication>
#include "MainWindow.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    MainWindow w;
    w.show();
    return app.exec();
}

####


2. MainWindow.h
Class: MainWindow (inherits from QMainWindow)

## Purpose:

The primary GUI class. Sets up the main layout, control panel (Start/Pause/Stop), building display, and event log.
Connects to SimulationController to start/stop the simulation, handle time stepping, and log messages.
Key Members:

- SimulationController *simulationController;
- Manages elevator logic and time steps.
- QTimer *simulationTimer;
- Triggers updateSimulation() each second.
- QList<ElevatorWidget*> elevatorWidgets;
- Holds the widgets that visually represent each elevator.
- QList<FloorWidget*> floorWidgets;
- Holds the widgets for each floor row (with Up/Down buttons).
- Control Buttons: startBtn, pauseBtn, resumeBtn, stopBtn, etc.
- Slots: startSimulation(), pauseSimulation(), stopSimulation(), updateSimulation(), etc.

## Typical Responsibilities: ## 

- Creating and laying out the GUI elements.
- Handling button clicks to control the simulation.
- Forwarding log messages to a QTextEdit console.
- Displaying simulation time and elevator statuses.




3. MainWindow.cpp
Implements: MainWindow class methods declared in MainWindow.h.

## Key Methods: ## 

Constructor:
- Instantiates simulationController and simulationTimer.
Connects signals/slots.
- Calls setupUI() to build the interface.
setupUI():
- Creates layouts, calls createElevatorDisplay(), createControlPanel(), and createLogConsole().
startSimulation():
Hard‐codes passenger and safety events (scenarios).
- Calls simulationController->configure(...), then simulationController->start().
- Starts the simulationTimer to advance time.
updateSimulation():
Called by the timer each second.
- Calls simulationController->advanceTime(), updates the UI.
- updateElevatorDisplay():
- Fetches ElevatorStatus from the controller and updates each ElevatorWidget.
- logMessage(const QString &message):
- Appends messages to the event log (QTextEdit).




4. SimulationController.h
Class: SimulationController (inherits from QObject)

Purpose:

AKA The “brain” of the simulation, managing:
- Current time (m_currentTime)
- Elevator states (via QVector<ElevatorStatus>)
- Passenger events (PassengerEvent)
- Safety events (SafetyEvent)
- Processes events each time step and updates elevator movement/doors.

## Key Data Structures: ##
- struct PassengerEvent: time, sourceFloor, destinationFloor, type.
- struct SafetyEvent: time, elevatorId (or -1 for building‐wide), type (Fire, Overload), bool active.
- struct ElevatorStatus: id, currentFloor, destinationFloor, state (IDLE, MOVING, etc.), direction (UP, DOWN, NONE), doorOpen.
- struct Passenger (optional): to track individual passengers.

## Key Methods: ##

- configure(...): sets up floors/elevators and loads event lists.
- start(): resets time to 0, logs “started.”
- stop(): logs “stopped.”
- advanceTime(): increments current time, processes events, updates elevator states.
- processEvents(): calls processPassengerEvents() and processSafetyEvents().
- updateElevatorStates(): moves each elevator floor by floor, handles door states, checks for safety.
- Signals: messageLogged(const QString&) for logging to UI.


5. SimulationController.cpp
Implements: SimulationController class methods.

## Key Logic: ## 
- configure() sorts passenger/safety events by time, initializes elevator statuses.
- advanceTime():
- m_currentTime++,
- processEvents(),
- updateElevatorStates().
- processPassengerEvents():
- Checks if it->time == m_currentTime; if so, handle floor requests, create passenger objects, etc.
- processSafetyEvents():
- Activates or deactivates conditions (Fire, Overload, etc.).
- updateElevatorStates():
- If safety is active, set elevator to EMERGENCY.
- Otherwise, handle IDLE -> MOVING_UP -> DOOR_OPENING -> DOOR_CLOSING transitions.



6. ElevatorWidget.h
Class: ElevatorWidget (inherits from QWidget)

## Purpose: ##

- Graphically represent a single elevator’s position, state, door status, and passenger count.
- Draw a “shaft,” a colored rectangle for the elevator car, floor lines, and optional direction arrows.


## Key Members: ##
- ElevatorState state; (IDLE, MOVING_UP, MOVING_DOWN, DOOR_OPEN, EMERGENCY, etc.)
- Direction direction; (UP, DOWN, NONE)
- Labels: floorLabel, stateLabel, passengerCountLabel
- paintEvent(QPaintEvent *): custom drawing code.


## Methods: ## 

- updateElevator(int currentFloor, ElevatorState, int destFloor, Direction, int passengerCount):
- Updates internal data and calls update() to repaint.
- setSafetyCondition(bool hasCondition, const QString &type):
- Marks the elevator as red if a safety condition is active.


7. ElevatorWidget.cpp
Implements: ElevatorWidget methods.
## Key Points: ##
paintEvent() draws:
- A rectangle for the shaft.
- A smaller rectangle for the car at the correct Y position based on currentFloor.
- Dashed lines for each floor.
- Arrows if direction != NONE.
- A red color or text if hasSafetyCondition is true.


8. FloorWidget.h
Class: FloorWidget (inherits from QWidget)

## Purpose: ## 
- Represents a single floor row with an Up/Down button.
- The UI can optionally highlight the pressed button and emit signals for upButtonPressed(int floor) or downButtonPressed(int floor).

## Key Members: ##
- floorNumber (0-based)
- totalFloors
- QPushButton *upButton;
- QPushButton *downButton;
- Signals: upButtonPressed(int), downButtonPressed(int)


9. FloorWidget.cpp
Implements: FloorWidget methods.
## Key Points: ## 
Constructor:
- Creates the floor label ("Floor X") and up/down buttons.
- Disables the Up button if this is the top floor; disables Down if ground floor.
- Connects button clicks to onUpButtonClicked() and onDownButtonClicked().
- setUpButtonActive(bool) & setDownButtonActive(bool):
- Changes button color to indicate it’s pressed.
- Slots: onUpButtonClicked() => emits upButtonPressed(floorNumber).

## In the GUI: ##
- Press Start to begin the simulation (with whichever scenario is uncommented in startSimulation()).
- Observe the Event Log and watch each elevator’s floor and state in the ElevatorWidget area.
- Use Pause, Resume, or Stop to control the simulation.


## Additional Notes ## 
- Hard‐coded Scenarios: In MainWindow::startSimulation(), you’ll find blocks for SCN1..SCN4. Uncomment exactly one block at a time, rebuild, and run.
- Passenger Counting: Currently, we pass a passengerCount = 0 to ElevatorWidget. 
- Memory Management: All widgets (ElevatorWidget, FloorWidget) are parented to the main window or group boxes, so Qt handles cleanup automatically.
- Safety Conditions: The simulation checks if any safety condition is active (Fire, DoorObstacle, etc.) each step and sets the elevator(s) to EMERGENCY if true.